# L-Bracket Mount — SolidWorks CAD Files

Design ID: bracket-01
Software: SolidWorks 2024

Files included:
- bracket-01.SLDPRT  (Part File)
- bracket-01.SLDDRW  (Drawing File)

Note: These are placeholder files. Actual CAD files will be added soon.
Designed by Pasindu Wijesinghe
