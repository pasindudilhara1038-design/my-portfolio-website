# Stepped Shaft — SolidWorks CAD Files

Design ID: shaft-01
Software: SolidWorks 2024

Files included:
- shaft-01.SLDPRT  (Part File)
- shaft-01.SLDDRW  (Drawing File)

Note: These are placeholder files. Actual CAD files will be added soon.
Designed by Pasindu Wijesinghe
