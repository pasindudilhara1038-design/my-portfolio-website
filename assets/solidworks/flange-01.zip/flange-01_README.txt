# Pipe Flange Coupling — SolidWorks CAD Files

Design ID: flange-01
Software: SolidWorks 2024

Files included:
- flange-01.SLDPRT  (Part File)
- flange-01.SLDDRW  (Drawing File)

Note: These are placeholder files. Actual CAD files will be added soon.
Designed by Pasindu Wijesinghe
