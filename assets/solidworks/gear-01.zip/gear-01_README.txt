# Spur Gear — SolidWorks CAD Files

Design ID: gear-01
Software: SolidWorks 2024

Files included:
- gear-01.SLDPRT  (Part File)
- gear-01.SLDDRW  (Drawing File)

Note: These are placeholder files. Actual CAD files will be added soon.
Designed by Pasindu Wijesinghe
